__author__ = ''

#__all__ = ["_and", "_or", "_not"]
